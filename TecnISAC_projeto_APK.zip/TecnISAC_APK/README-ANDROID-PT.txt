TecnISAC para Android — projeto preparado para gerar APK

IMPORTANTE
- Este ZIP contém o código-fonte e uma configuração de compilação automática. Não contém ainda um APK compilado.
- A compilação é feita num ambiente Linux online através do GitHub Actions; não é necessário instalar Android Studio no telemóvel.
- O APK gerado é de teste (debug), não é uma versão assinada para publicação na Play Store.
- A aplicação HTML pode abrir sem servidor, mas as funções que dependem de IA só funcionarão quando o backend estiver alojado online e o endereço estiver configurado no TecnISAC.
- Nunca coloques uma chave de API dentro de www/index.html nem publiques segredos no repositório.

COMO GERAR O APK USANDO O ANDROID
1. Descarrega e extrai este ZIP no telemóvel.
2. Entra em https://github.com e inicia sessão ou cria uma conta com ajuda de um adulto de confiança.
3. Cria um repositório novo chamado TecnISAC-Android. Para proteger o código enquanto estás a testar, escolhe Private.
4. No repositório, usa Add file > Upload files e envia os ficheiros e pastas extraídos deste ZIP. É importante manter a pasta .github/workflows e o ficheiro build-android.yml. Se o navegador não mostrar ficheiros ocultos/pastas corretamente, será necessário usar um computador ou um ambiente de desenvolvimento online.
5. Faz commit dos ficheiros na branch main.
6. Abre o separador Actions no repositório e seleciona “Construir APK TecnISAC”. Toca em Run workflow e confirma.
7. Espera até o workflow terminar com sucesso (marca verde). Abre a execução concluída e, em Artifacts, descarrega “TecnISAC-APK-debug”.
8. Extrai o ZIP do artefacto e toca em app-debug.apk para iniciar a instalação. O Android pode pedir autorização para instalar aplicações desta origem; só continua se reconheceres o ficheiro que acabaste de gerar.

SE O WORKFLOW FALHAR
Abre a execução em Actions, localiza a etapa vermelha e copia apenas a mensagem de erro — nunca tokens, passwords ou chaves secretas — para pedir ajuda.

REQUISITOS
Capacitor 8 requer Node.js 22+ para desenvolvimento e Android SDK/Android Studio para compilação local. Este projeto usa GitHub Actions para fazer a compilação fora do telemóvel.

ESTADO DO PROJETO
- Aplicação HTML copiada para www/index.html.
- Identificador Android: mz.tecnisac.app.
- Nome visível: TecnISAC.
- Workflow para gerar APK debug incluído.
